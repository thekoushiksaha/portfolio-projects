package com.koushik.outspend.publicapi.model;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record ContactRequest(
        @NotBlank(message = "Name is required") @Size(max = 100, message = "Name can be up to 100 characters") String name,

        @NotBlank(message = "Email is required") @Email(message = "Enter a valid email") @Size(max = 150, message = "Email can be up to 150 characters") String email,

        @NotBlank(message = "Message is required") @Size(max = 2000, message = "Message must be up to 2000 characters") String message) {

}
